document.getElementById("activityForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Evita el envío del formulario
    
    // Obtener los valores de los campos
    var activity = document.getElementById("activity").value;
    var date = document.getElementById("date").value;
    
    // Crear un nuevo elemento de lista
    var newItem = document.createElement("li");
    newItem.textContent = activity + " - " + date;
    
    // Crear el botón de eliminar
    var deleteButton = document.createElement("button");
    deleteButton.textContent = "Eliminar";
    
    // Agregar el evento de clic al botón de eliminar
    deleteButton.addEventListener("click", function() {
      newItem.remove();
    });
    
    // Agregar el botón de eliminar al elemento de lista
    newItem.appendChild(deleteButton);
    
    // Agregar el elemento a la lista
    var list = document.getElementById("activityList");
    list.appendChild(newItem);
    
    // Limpiar los campos del formulario
    document.getElementById("activity").value = "";
    document.getElementById("date").value = "";
  });
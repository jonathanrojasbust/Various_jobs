-- Insertar en la tabla procedure
		CREATE PROCEDURE InsertSucursales
			@codigoSucursal INT,
			@direccion VARCHAR(100),
			@telefono VARCHAR(20)
		AS
		BEGIN
			INSERT INTO sucursales (codigoSucursal, direccion, telefono)
			VALUES (@codigoSucursal, @direccion, @telefono)
		END

		EXEC InsertSucursales @codigoSucursal = 25, @direccion = 'carrera 64 # 86 a 213', @telefono = '312312312';

  -- ver stadisticas 
		  CREATE PROCEDURE GetTableIOStatistics
			@tableName NVARCHAR(128)
		AS
		BEGIN
			SET NOCOUNT ON;
			SET STATISTICS IO ON;

			DECLARE @sql NVARCHAR(MAX) = N'SELECT * FROM ' + QUOTENAME(@tableName);

			EXEC sp_executesql @sql;

			SET STATISTICS IO OFF;
		END
		-- Message = Table 'sucursales'. Scan count 1, logical reads 2, physical reads 0, 
		-- page server reads 0, read-ahead reads 0, page server read-ahead reads 0, lob logical reads 0,
		-- se ve en el message de sql no en los results 
		EXEC GetTableIOStatistics @tableName = 'sucursales';


-- update table procedure
		CREATE PROCEDURE UpdateSucursal
			@codigoSucursal INT,
			@direccion VARCHAR(100),
			@telefono VARCHAR(20)
		AS
		BEGIN
			UPDATE sucursales
			SET direccion = @direccion, telefono = @telefono
			WHERE codigoSucursal = @codigoSucursal
		END
		--executor 
		EXEC UpdateSucursal @codigoSucursal = 9, @direccion = 'carrera 98 # 89 a ', @telefono = '604123123'




-- delete 

		CREATE PROCEDURE DeleteReserva
			@idReservasHospedaje INT
		AS
		BEGIN
			DELETE FROM reservasHospedaje
			WHERE idReservasHospedaje = @idReservasHospedaje
		END

		EXEC DeleteReserva @idReservasHospedaje = 20

--


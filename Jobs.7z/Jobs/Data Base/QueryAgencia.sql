
-- querys
use AgenciaViajes
--mayor
SELECT nombre FROM hoteles WHERE precioPersona > 400;
--mayorIgual 
SELECT numeroVuelo FROM vuelos WHERE precioEquipaje >= 400;
--menor
SELECT nombre FROM hoteles WHERE precioPersona < 300;
--menorIgual
SELECT numeroVuelo FROM vuelos WHERE precioPersona <= 300;
--diferente
SELECT numeroVuelo FROM vuelos WHERE claseViaje <> 'Primera';
--igual
SELECT origen FROM vuelos WHERE claseViaje = 'Turista';
--between
SELECT nombre FROM hoteles WHERE plazasDisponibles BETWEEN 100 AND 200;
--&&
SELECT origen FROM vuelos WHERE claseViaje = 'Turista' AND precioPersona <= 300;
-- ||
SELECT nombre FROM hoteles WHERE  precioPersona > 400 OR ciudad = 'Los Angeles';
-- IN
SELECT nombre FROM hoteles WHERE   ciudad IN ('Los Angeles','Chicago','San Francisco');
-- like
SELECT celular, nombre FROM turistas WHERE nombre like '%a'

--inner join 
-- traer informacion de los turistas y hoteles que hicieron reservas en hotel con cierto nombre 
SELECT rh.idReservasHospedaje, t.nombre, t.apellidos, t.correo, t.celular, h.nombre AS nombreHotel, h.direccion AS direccionHotel
FROM reservasHospedaje rh
INNER JOIN turistas t ON rh.documentoTurista = t.documentoTurista
INNER JOIN hoteles h ON rh.codigoHotel = h.codigoHotel
WHERE h.nombre LIKE 'The%';

--traer la informacion de los turistas que tomaron vuelos despues de una fecha 
SELECT rv.idReservasVuelos, t.nombre, t.apellidos, t.correo, t.celular, v.fechaHora, v.origen, v.destino
FROM reservasVuelos rv
INNER JOIN turistas t ON rv.documentoTurista = t.documentoTurista
INNER JOIN vuelos v ON rv.numeroVuelo = v.numeroVuelo
WHERE v.fechaHora >= Convert(datetime, '2023-06-19' ) ;

--traer las la sucursalr de andrea y el id contrataciones
SELECT c.idContrataciones, t.nombre, t.apellidos, t.correo, t.celular, s.direccion AS direccionSucursal, s.telefono AS telefonoSucursal
FROM contrataciones c
INNER JOIN turistas t ON c.documentoTurista = t.documentoTurista
INNER JOIN sucursales s ON c.codigoSucursal = s.codigoSucursal
WHERE t.nombre = 'Andrea';

-- traer las reservas de vuelos y hospedaje de andrea 
SELECT rh.idReservasHospedaje, rv.idReservasVuelos, t.nombre, t.apellidos, t.correo, t.celular
FROM reservasHospedaje rh
INNER JOIN reservasVuelos rv ON rh.documentoTurista = rv.documentoTurista
INNER JOIN turistas t ON rh.documentoTurista = t.documentoTurista
WHERE t.nombre = 'Andrea';

--campos calculados 

--calcular el precio segun la clase del vuelo 
SELECT rv.idReservasVuelos, v.fechaHora, v.origen, v.destino, v.precioPersona,
       rv.claseViaje,
       v.precioPersona * (CASE WHEN rv.claseViaje = 'Turista' THEN 1 ELSE 1.5 END) AS precioTotal
FROM reservasVuelos rv
INNER JOIN vuelos v ON rv.numeroVuelo = v.numeroVuelo;

--duracion de la estadia 
SELECT rh.idReservasHospedaje, rh.fechaLlegada, rh.fechaPartida,
       DATEDIFF(DAY, rh.fechaLlegada, rh.fechaPartida) AS duracionEstadia
FROM reservasHospedaje rh;

--calcular el precio total de la resserva 
SELECT rh.idReservasHospedaje, h.nombre AS nombreHotel, rh.fechaLlegada, rh.fechaPartida,
       DATEDIFF(DAY, rh.fechaLlegada, rh.fechaPartida) AS numeroDias,
       DATEDIFF(DAY, rh.fechaLlegada, rh.fechaPartida) * h.precioPersona AS costoTotal
FROM reservasHospedaje rh
INNER JOIN hoteles h ON rh.codigoHotel = h.codigoHotel;

--seleccionar el nombre completo 
SELECT documentoTurista, CONCAT(nombre, ' ', apellidos) AS nombreCompleto
FROM turistas;

--Consultas de agrupacion 
--total de las reservaciones de los hoteles 
SELECT h.codigoHotel, h.nombre, COUNT(rh.idReservasHospedaje) AS totalReservations
FROM hoteles h
JOIN reservasHospedaje rh ON h.codigoHotel = rh.codigoHotel
GROUP BY h.codigoHotel, h.nombre;

-- el promedio de el precio por persona de los hotles 
SELECT AVG(precioPersona) AS averagePricePerPerson
FROM hoteles;

--el maximo numero de plazas  de los hoteles 
SELECT nombre, MAX(plazasDisponibles) AS maxAvailableSeats
FROM hoteles
GROUP BY nombre;





CREATE DATABASE AgenciaViajes;
USE AgenciaViajes;

CREATE TABLE sucursales (
  codigoSucursal INT PRIMARY KEY,
  direccion VARCHAR(100),
  telefono VARCHAR(20)
);

CREATE TABLE hoteles (
  codigoHotel INT PRIMARY KEY,
  nombre VARCHAR(100),
  direccion VARCHAR(100),
  ciudad VARCHAR(50),
  paginaWeb VARCHAR(50),
  plazasDisponibles INT,
  precioPersona INT
);

CREATE TABLE vuelos (
  numeroVuelo INT PRIMARY KEY ,
  fechaHora DATETIME,
  origen VARCHAR(50),
  destino VARCHAR(50),
  precioPersona INT,
  precioEquipaje INT,
  claseViaje VARCHAR(50)
);

CREATE TABLE turistas (
  documentoTurista INT PRIMARY KEY, 
  nombre VARCHAR(50),
  apellidos VARCHAR(100),
  correo VARCHAR(100),
  celular VARCHAR(20)
);

CREATE TABLE reservasHospedaje (
  idReservasHospedaje INT PRIMARY KEY,
  documentoTurista INT,
  codigoHotel INT,
  fechaLlegada DATE,
  fechaPartida DATE,
  regimenHospedaje VARCHAR(30),
  FOREIGN KEY (documentoTurista) REFERENCES turistas(documentoTurista),
  FOREIGN KEY (codigoHotel) REFERENCES hoteles(codigoHotel)
);

CREATE TABLE reservasVuelos (
  idReservasVuelos INT PRIMARY KEY,
  documentoTurista INT,
  numeroVuelo INT,
  claseViaje VARCHAR(30),
  FOREIGN KEY (documentoTurista) REFERENCES turistas(documentoTurista),
  FOREIGN KEY (numeroVuelo) REFERENCES vuelos(numeroVuelo)
);

CREATE TABLE contrataciones (
  idContrataciones INT PRIMARY KEY,
  codigoSucursal INT,
  documentoTurista INT,
  FOREIGN KEY (codigoSucursal) REFERENCES sucursales(codigoSucursal),
  FOREIGN KEY (documentoTurista) REFERENCES turistas(documentoTurista)
);